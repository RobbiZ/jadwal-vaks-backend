<?php 
	define('DB_HOST','localhost');
	define('DB_USERNAME','root');
	define('DB_PASSWORD','');
	define('DB_NAME','db_vaksinasi');

	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAAKmrva4U:APA91bFBJuTp6ehaT8Wbp-XCFdeGckkuCeBU3PTz4Q9T9sFqJ57Dy-7v6mOVWHoR4Ikypjxe4QdT0bv1ACqeWcuhKj3fU0fte8cw6STAH4yRelPejOW_jMvyK6LJciCNiQVkq2O1agZy');
?>