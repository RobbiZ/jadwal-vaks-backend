<html style="zoom: 1.1;">

<head>
   
    <title>Sistem Penjadwalan Vaksinasi</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
    
    <div class="middle-box text-center loginscreen animated fadeInDown">
        <div>
            <div>
                <center><img alt="logo" class="img-responsive" src="img/mab-logo.png" style="zoom: 0.5;"></center>
            </div>
            <br/><br/>
            <b><h3>SISTEM PENJADWALAN VAKSINASI</h3></b></br>
            <b>Silahkan Log In</b>
            <form class="m-t" role="form" action="login.php" method="POST">
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Username" required="" name="username">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="" name="password">
                </div>
                <button type="submit" class="btn btn-success block full-width m-b">Login</button>
            </form>
           
        </div>
    </div>

<!-- Mainly scripts -->
<script src="js/jquery-2.1.1.js"></script>
<script src="js/bootstrap.min.js"></script>
    
</body>

</html>